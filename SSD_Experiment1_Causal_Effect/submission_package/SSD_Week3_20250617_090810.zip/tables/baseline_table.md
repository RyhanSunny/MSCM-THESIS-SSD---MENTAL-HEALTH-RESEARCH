# Table 1. Baseline Characteristics

*Generated: 2025-06-17 03:26:02*

| Characteristic | Exposed | Control | SMD |
|---|---|---|---|
| N (%) | 142,986 (57.2) | 107,039 (42.8) | - |
| Age, mean (SD) | 57.6 (17.0) | 44.8 (19.4) | 0.699 |
| Male sex, n (%) | 0 (0.0) | 0 (0.0) | 0.000 |
| Charlson score, mean (SD) | 0.44 (0.88) | 0.22 (0.64) | 0.000 |
| Baseline encounters, mean (SD) | 3.0 (1.7) | 3.0 (1.7) | 0.003 |


---
*SMD: Standardized Mean Difference; IRR: Incidence Rate Ratio; CI: Confidence Interval*
