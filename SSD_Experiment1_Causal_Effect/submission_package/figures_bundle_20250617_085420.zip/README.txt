High-Resolution Figures Bundle
Generated: 2025-06-17 08:54:20

Contents:
- All figures in SVG (vector) and PNG (300 DPI) formats
- Metadata files with generation details
- Suitable for manuscript submission

DPI: 300