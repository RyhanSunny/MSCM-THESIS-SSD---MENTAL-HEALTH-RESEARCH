Supplementary Documentation Bundle
Generated: 2025-06-17 08:58:08

Contents:
- Methods_Supplement.md/tex: Detailed statistical methods
- STROBE_CI_Checklist.md: Reporting checklist with line references
- ROBINS_I_Assessment.md: Risk of bias assessment
- Glossary.md: Definition of terms

All documents formatted for journal submission.